from django.shortcuts import render
from django.http import HttpResponse
from .models import MarriageFeed,ImageMarriageFeed,ReviewMarriage
from .models import BirthdayFeed,ImageBirthdayFeed,ReviewBirthday
from .models import BaptismFeed,ImageBaptismFeed,ReviewBaptism
from .models import HolyFeed,ImageHolyFeed,ReviewHolyFeed
from .models import SavedDates,ImageSaveFeed,ReviewSave

def demoTest(request):
    return HttpResponse("Demno Test")

def marriagefeedList(request):
    marriage=MarriageFeed.objects.all()
    context={'marriage':marriage}
    return render(request,'content/marriage.html',context)

def marriagesingle(request,pk):
    indMarriage=MarriageFeed.objects.get(id=pk)
    imgNar=ImageMarriageFeed.objects.filter(marriage=pk)
    reviewMar=ReviewMarriage.objects.filter(marriage=pk)
    return render(request,"content/singleMarraigle.html",{'singlemarriagle':indMarriage,'imgMar':imgNar,'review':reviewMar})



def birthdayfeedList(request):
    birthday=BirthdayFeed.objects.all()
    context={'birthday':birthday}
    return render(request,'content/birthday.html',context)

def birthdaysingle(request,pk):
    indBirthday=BirthdayFeed.objects.get(id=pk)
    imgBir=ImageBirthdayFeed.objects.filter(marriage=pk)
    reviewBir=ReviewBirthday.objects.filter(marriage=pk)
    return render(request,"content/singleBirthday.html",{'singleBirthday':indBirthday,'imgBir':imgBir,'review':reviewBir})



def baptismfeedList(request):
    baptism=BaptismFeed.objects.all()
    context={'baptism':baptism}
    return render(request,'content/baptism.html',context)

def baptismsingle(request,pk):
    indBaptism=BaptismFeed.objects.get(id=pk)
    imgBap=ImageBaptismFeed.objects.filter(marriage=pk)
    reviewBap=ReviewBaptism.objects.filter(marriage=pk)
    return render(request,"content/singleBaptism.html",{'singleBaptism':indBaptism,'imgBap':imgBap,'review':reviewBap})



def holyfeedList(request):
    holy=HolyFeed.objects.all()
    context={'holy':holy}
    return render(request,'content/holyCommunion.html',context)

def holysingle(request,pk):
    indBaptism=HolyFeed.objects.get(id=pk)
    imgBap=ImageHolyFeed.objects.filter(holyfeed=pk)
    reviewBap=ReviewHolyFeed.objects.filter(holyfeed=pk)
    return render(request,"content/singleBaptism.html",{'singleBaptism':indBaptism,'imgBap':imgBap,'review':reviewBap})


def savetheDate(request):
    saved=SavedDates.objects.all()
    return render(request,"content/saveDate.html",{'saved':saved})


def savedatesingle(request,pk):
    indBirthday=SavedDates.objects.get(id=pk)
    imgBir=ImageSaveFeed.objects.filter(marriage=pk)
    reviewBir=ReviewSave.objects.filter(marriage=pk)
    return render(request,"content/singleBirthday.html",{'singleBirthday':indBirthday,'imgBir':imgBir,'review':reviewBir})
