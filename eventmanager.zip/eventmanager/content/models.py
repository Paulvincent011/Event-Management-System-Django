from django.db import models

class MarriageFeed(models.Model):
    name=models.CharField(max_length=50)
    price=models.IntegerField()
    smallAbout=models.TextField()
    longAbout=models.TextField()
    thumbnail=models.TextField(blank = False,default="img")
    
    def __str__(self):
        return self.name

class ImageMarriageFeed(models.Model):
    marriage=models.ForeignKey("MarriageFeed", on_delete=models.CASCADE)
    imageurl=models.TextField()

class ReviewMarriage(models.Model):
    marriage=models.ForeignKey("MarriageFeed", on_delete=models.CASCADE)
    posted_by=models.CharField(max_length=50)
    review=models.TextField()

class BirthdayFeed(models.Model):
    name=models.CharField(max_length=50)
    price=models.IntegerField()
    smallAbout=models.TextField()
    longAbout=models.TextField()
    thumbnail=models.TextField(blank = False,default="img")
    
    def __str__(self):
        return self.name

class ImageBirthdayFeed(models.Model):
    marriage=models.ForeignKey("BirthdayFeed", on_delete=models.CASCADE)
    imageurl=models.TextField()

class ReviewBirthday(models.Model):
    marriage=models.ForeignKey("BirthdayFeed", on_delete=models.CASCADE)
    posted_by=models.CharField(max_length=50)
    review=models.TextField()

class BaptismFeed(models.Model):
    name=models.CharField(max_length=50)
    price=models.IntegerField()
    smallAbout=models.TextField()
    longAbout=models.TextField()
    thumbnail=models.TextField(blank = False,default="img")
    
    def __str__(self):
        return self.name

class ImageBaptismFeed(models.Model):
    marriage=models.ForeignKey("BaptismFeed", on_delete=models.CASCADE)
    imageurl=models.TextField()

class ReviewBaptism(models.Model):
    marriage=models.ForeignKey("BaptismFeed", on_delete=models.CASCADE)
    posted_by=models.CharField(max_length=50)
    review=models.TextField()


# Holy Communion
class HolyFeed(models.Model):
    name=models.CharField(max_length=50)
    price=models.IntegerField()
    smallAbout=models.TextField()
    longAbout=models.TextField()
    thumbnail=models.TextField(blank = False,default="img")
    
    def __str__(self):
        return self.name

class ImageHolyFeed(models.Model):
    holyfeed=models.ForeignKey("HolyFeed", on_delete=models.CASCADE)
    imageurl=models.TextField()

class ReviewHolyFeed(models.Model):
    holyfeed=models.ForeignKey("HolyFeed", on_delete=models.CASCADE)
    posted_by=models.CharField(max_length=50)
    review=models.TextField()


class SavedDates(models.Model):
    name=models.CharField(max_length=50)
    eventType=models.CharField(max_length=50)
    price=models.IntegerField()
    smallAbout=models.TextField()
    longAbout=models.TextField()
    thumbnail=models.TextField(blank = False,default="img")


class ImageSaveFeed(models.Model):
    marriage=models.ForeignKey("SavedDates", on_delete=models.CASCADE)
    imageurl=models.TextField()

class ReviewSave(models.Model):
    marriage=models.ForeignKey("SavedDates", on_delete=models.CASCADE)
    posted_by=models.CharField(max_length=50)
    review=models.TextField()