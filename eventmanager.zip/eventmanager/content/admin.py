from django.contrib import admin
from . import models 
# Register your models here.

admin.site.register(models.MarriageFeed)
admin.site.register(models.ImageMarriageFeed)
admin.site.register(models.ReviewMarriage)


admin.site.register(models.BirthdayFeed)
admin.site.register(models.ImageBirthdayFeed)
admin.site.register(models.ReviewBirthday)


admin.site.register(models.BaptismFeed)
admin.site.register(models.ImageBaptismFeed)
admin.site.register(models.ReviewBaptism)

admin.site.register(models.HolyFeed)
admin.site.register(models.ImageHolyFeed)
admin.site.register(models.ReviewHolyFeed)


admin.site.register(models.SavedDates)
admin.site.register(models.ImageSaveFeed)
admin.site.register(models.ReviewSave)