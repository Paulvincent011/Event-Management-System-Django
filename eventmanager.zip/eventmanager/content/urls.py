from . import views
from django.urls import path

urlpatterns = [
    path("marriage/",views.marriagefeedList,name="marriage-list"),
    path('singlemarriagle/<str:pk>',views.marriagesingle,name="single-marr"),

    path("birthday/",views.birthdayfeedList,name="birthday-list"),
    path('singlebirthday/<str:pk>',views.birthdaysingle,name="single-birthday"),

    path("baptism/",views.baptismfeedList,name="baptism-list"),
    path('singlebaptism/<str:pk>',views.baptismsingle,name="single-baptism"),

    path("holycommunion/",views.holyfeedList,name="holy-list"),
    path('singleholycommunion/<str:pk>',views.holysingle,name="single-holy"),

    path("saves-dates/",views.savetheDate,name="save-the-date"),
    path("singlesaveDate/<str:pk>",views.savedatesingle,name="single-save")
]
