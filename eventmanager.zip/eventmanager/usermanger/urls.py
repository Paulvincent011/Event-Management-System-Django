from . import views
from django.urls import path
from django.contrib.auth import views as auth_views
from django.views.generic.base import RedirectView



urlpatterns = [
    path('adminPage/', RedirectView.as_view(url='/admin'),name="admin-page"),
    path('',views.home,name="homePage"),
    path('register/',views.register,name="registerPage"),
    path('login/', auth_views.LoginView.as_view(template_name='usermanger/login.html'), name='loginPage'),
    path('logout/', auth_views.LogoutView.as_view(template_name='usermanger/home.html'), name='logoutPage'),
    path('accounts/profile/',views.demotest,name="demotry"),
    path('about/',views.aboutPage,name="aboutPage")
]