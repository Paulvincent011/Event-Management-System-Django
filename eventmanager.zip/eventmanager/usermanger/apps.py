from django.apps import AppConfig


class UsermangerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'usermanger'
