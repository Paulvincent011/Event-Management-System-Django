from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import UserRegisterForm

# Create your views here.

def home(request):
    return render(request,'usermanger/home.html')


# def register(request):
#     return render(request,'usermanger/register.html')




def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}!')
            return redirect('loginPage')
    else:
        form = UserRegisterForm()
    return render(request, 'usermanger/register.html', {'form': form})


def demotest(request):
    return redirect('homePage')


def aboutPage(request):
    return render(request, 'usermanger/home.html')